﻿using Microsoft.AspNetCore.Identity;

namespace CasualGamesDb.Models
{
    public class User : IdentityUser
    {
        public List<CasualGame> GamesInFavorite { get; set; } = new();
    }
}
