﻿using CasualGamesDb.Models;

namespace CasualGamesDb
{
    public static class DataSource
    {
        public static List<CasualGame> CasualGames = new List<CasualGame>
        {
            new CasualGame
            {
                Id = 1,
                Name = "Stardew Valley",
                Description = "Симулятор фермерства, где вы можете выращивать растения, ухаживать за животными, исследовать шахты и общаться с жителями деревни.",
                ImagePath = "/img/stardew_valley.jpg",
                VideoLink = "https://www.youtube.com/embed/ot7uXNQskhs?si=ZilG0NJACMEdkFox"
            },
            new CasualGame
            {
                Id = 2,
                Name = "Among Us",
                Description = "Многопользовательская игра, в которой игроки выполняют задания на космическом корабле, пытаясь выявить предателя среди них.",
                ImagePath = "/img/among_us.jpg",
                VideoLink = "https://www.youtube.com/embed/0YKjFoGxbec?si=LJY2VGmUB_r-Esk-"
            },
            new CasualGame
            {
                Id = 3,
                Name = "Slime Rancher",
                Description = "Игра-симулятор, в которой игрок управляет фермой для слаймов, собирая, выращивая и продавая их.",
                ImagePath = "/img/slime_rancher.jpg",
                VideoLink = "https://www.youtube.com/embed/oOL-dsa79Xs?si=GOkYxdIphfvfXKy2"
            },
            new CasualGame
            {
                Id = 4,
                Name = "Terraria",
                Description = "Песочница, где игроки могут исследовать, строить и сражаться с различными существами в процедурно сгенерированном мире.",
                ImagePath = "/img/terraria.jpg",
                VideoLink = "https://www.youtube.com/embed/6nUvWkD8rAE?si=w1wFc_GIPoqR2LMV"
            },
            new CasualGame
            {
                Id = 5,
                Name = "The Sims 4",
                Description = "Жизненный симулятор, где игроки создают и управляют персонажами, развивая их жизни, строя дома и исследуя различные сценарии.",
                ImagePath = "/img/sims_4.jpg",
                VideoLink = "https://www.youtube.com/embed/DyNv44QR14g?si=ZNkLTQtXFrE2c_TI"
            },
            new CasualGame
            {
                Id = 6,
                Name = "Overcooked! 2",
                Description = "Кооперативная игра, в которой игроки работают вместе, чтобы готовить и подавать разнообразные блюда в хаотичной кухне.",
                ImagePath = "/img/overcooked_2.jpg",
                VideoLink = "https://www.youtube.com/embed/lcVISRmANIo?si=UifwZUOgTkKLHRe-"
            },
            new CasualGame
            {
                Id = 7,
                Name = "Fall Guys: Ultimate Knockout",
                Description = "Многопользовательская игра, где игроки соревнуются в серии комичных и хаотичных мини-игр, стремясь стать последним выжившим.",
                ImagePath = "/img/fall_guys.jpg",
                VideoLink = "https://www.youtube.com/embed/Wj3dUvGLjNQ?si=4fmhEKnvpqUpni4g"
            },
            new CasualGame
            {
                Id = 8,
                Name = "Escape From Tarkov",
                Description = "Казуальный многопользовательский шутер с элементами выживания, где игроки сражаются в реалистичных условиях, собирая лут и избегая опасностей.",
                ImagePath = "/img/escape_from_tarkov.jpg",
                VideoLink = "https://www.youtube.com/embed/8R5t3a2jT4A?si=vjsk7uzEZejbvueI"
            }
        };
    }
}
