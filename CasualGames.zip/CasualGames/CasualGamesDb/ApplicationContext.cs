﻿using CasualGamesDb;
using CasualGamesDb.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CasualGamesDb
{
    public class ApplicationContext : IdentityDbContext<User>
    {
        public ApplicationContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<CasualGame> CasualGames { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<CasualGame>()
                .HasData(DataSource.CasualGames);
            base.OnModelCreating(builder);
        }
    }
}
