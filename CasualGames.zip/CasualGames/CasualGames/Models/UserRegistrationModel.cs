﻿using System.ComponentModel.DataAnnotations;

namespace CasualGames.Models
{
    public class UserRegistrationModel
    {
        [Required(ErrorMessage = "Введите имя пользователя")]
        [StringLength(maximumLength: 15, MinimumLength = 4, ErrorMessage = "Длина имени пользователя должна составлять от 4 до 15 символов")]
        public required string User { get; set; }
        [Required(ErrorMessage = "Введите почту")]
        [EmailAddress(ErrorMessage = "Почта введена неправильно")]
        public required string ContactEmail { get; set; }
        [Required(ErrorMessage = "Введите пароль")]
        [DataType(DataType.Password)]
        [StringLength(15, MinimumLength = 4, ErrorMessage = "Длина пароля должна составлять от 4 до 15 символов")]
        public required string UserPassword { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public required string UserPasswordConfirmation { get; set; }
    }
}
