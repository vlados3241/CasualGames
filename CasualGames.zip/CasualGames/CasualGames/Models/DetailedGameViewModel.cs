﻿namespace CasualGames.Models
{
    public class DetailedGameViewModel
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required string ImagePath { get; set; }
        public required string VideoLink { get; set; }
        public required string Description { get; set; }
        public required bool IsInUserFavorite { get; set; }
    }
}
