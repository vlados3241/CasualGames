﻿namespace CasualGames.Models
{
    public class GameViewModel
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required string ImagePath { get; set; }
    }
}
