﻿using System.ComponentModel.DataAnnotations;

namespace CasualGames.Models
{
    public class UserLoginModel
    {
        [Required(ErrorMessage = "Введите имя пользователя")]
        public required string Username { get; set; }
        [Required(ErrorMessage = "Введите пароль")]
        [DataType(DataType.Password)]
        public required string Secret { get; set; }
        public required bool RememberMe { get; set; }
    }
}
