﻿using CasualGames.Models;
using CasualGamesDb;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace CasualGames.Controllers
{
    public class GamesController : Controller
    {
        private readonly ApplicationContext _dbContext;

        public GamesController(ApplicationContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> ListAllGames()
        {
            var gamesList = await _dbContext.CasualGames
                .Select(game => new GameViewModel
                {
                    Id = game.Id,
                    Name = game.Name,
                    ImagePath = game.ImagePath,
                })
                .ToArrayAsync();
            return View(gamesList);
        }

        [HttpGet]
        [Route("/detailed/{id}")]
        public async Task<IActionResult> GameDetails(int id)
        {
            var currentUserId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;

            var gameDetails = await _dbContext.CasualGames
                .Select(game => new DetailedGameViewModel
                {
                    Id = game.Id,
                    Name = game.Name,
                    ImagePath = game.ImagePath,
                    Description = game.Description,
                    IsInUserFavorite = _dbContext.Users.Any(user => user.Id == currentUserId && user.GamesInFavorite.Any(fav => fav.Id == game.Id)),
                    VideoLink = game.VideoLink
                })
                .FirstOrDefaultAsync(game => game.Id == id);
            return View(gameDetails);
        }

        [Authorize]
        [HttpGet]
        [Route("reserve/{id}")]
        public async Task<IActionResult> AddToFavorite(int id)
        {
            var currentUserId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var currentUser = await _dbContext.Users
                .Include(user => user.GamesInFavorite)
                .FirstOrDefaultAsync(user => user.Id == currentUserId);

            var gameToAdd = await _dbContext.CasualGames
                .FirstOrDefaultAsync(game => game.Id == id);

            if (currentUser != null && gameToAdd != null && !currentUser.GamesInFavorite.Contains(gameToAdd))
            {
                currentUser.GamesInFavorite.Add(gameToAdd);
                await _dbContext.SaveChangesAsync();
            }
            return RedirectToAction(nameof(GameDetails), new { id });
        }

        [Authorize]
        [HttpGet]
        [Route("unreserve/{id}")]
        public async Task<IActionResult> RemoveFromFavorite(int id)
        {
            var currentUserId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var currentUser = await _dbContext.Users
                .Include(user => user.GamesInFavorite)
                .FirstOrDefaultAsync(user => user.Id == currentUserId);

            var gameToRemove = currentUser?.GamesInFavorite.FirstOrDefault(game => game.Id == id);

            if (gameToRemove != null)
            {
                currentUser.GamesInFavorite.Remove(gameToRemove);
                await _dbContext.SaveChangesAsync();
            }

            return RedirectToAction(nameof(GameDetails), new { id });
        }
    }
}
