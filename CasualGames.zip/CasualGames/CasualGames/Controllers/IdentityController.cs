﻿using CasualGames.Models;
using CasualGamesDb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CasualGames.Controllers
{
    public class IdentityController : Controller
    {
        private readonly SignInManager<User> _authManager;
        private readonly UserManager<User> _accountManager;

        public IdentityController(SignInManager<User> authManager, UserManager<User> accountManager)
        {
            _authManager = authManager;
            _accountManager = accountManager;
        }

        [HttpPost]
        public async Task<IActionResult> SignIn(UserLoginModel loginInfo)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(SignInPage), loginInfo);
            }

            var signInOutcome = await _authManager.PasswordSignInAsync(
                loginInfo.Username,
                loginInfo.Secret,
                loginInfo.RememberMe,
                lockoutOnFailure: false
            );

            if (signInOutcome.Succeeded)
            {
                return RedirectToAction("MainPage", "Home");
            }

            ModelState.AddModelError(string.Empty, "Неверное имя пользователя или пароль");
            return View(nameof(SignInPage), loginInfo);
        }

        [HttpGet]
        [Route("login")]
        public IActionResult SignInPage()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SignUp(UserRegistrationModel registrationInfo)
        {
            if (registrationInfo.UserPasswordConfirmation != registrationInfo.UserPassword)
            {
                ModelState.AddModelError("", "Пароли разные");
            }
            if (!ModelState.IsValid)
            {
                return View(nameof(SignUpPage), registrationInfo);
            }

            var newUser = new User
            {
                UserName = registrationInfo.User,
                Email = registrationInfo.ContactEmail
            };

            var creationResult = await _accountManager.CreateAsync(newUser, registrationInfo.UserPassword);

            if (creationResult.Succeeded)
            {
                return RedirectToAction(nameof(SignInPage));
            }

            foreach (var error in creationResult.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }

            return View(nameof(SignUpPage), registrationInfo);
        }

        [HttpGet]
        [Route("register")]
        public IActionResult SignUpPage()
        {
            return View();
        }

        [Authorize]
        public async Task<IActionResult> LogOut()
        {
            await _authManager.SignOutAsync();
            return RedirectToAction("ListAllGames", "Games");
        }
    }
}
